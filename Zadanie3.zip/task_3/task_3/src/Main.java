import ui.mainPageUI;

public class Main {
    public static void main(String[] args) {

        mainPageUI mainPageUI = new mainPageUI();
        mainPageUI.displayMainPage();
    }
}