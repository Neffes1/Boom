import controllers.mainController;


public class Main {
    public static void main (String[] args){
        mainController.mainWork();
    }
}